<div class="fullwidthfooter text-white mt-5 pt-5 pb-5">
<footer class="container site-footer pt-4 pb-2">
 
	<div class="row">
    <div class="col-md-4 text-start footercompanytext">
        <?php dynamic_sidebar('footer-widget-area'); ?>
    </div>
    <div class="col-md-5">
      <div class="row">

          <div class="col-md-6 border-left ps-4">
            <h3 class="h5 pb-3">About</h3>
            <?php
              wp_nav_menu(array(
                  'theme_location' => 'footer_menu',
                  'depth'             => 3,
                  'menu_class'     => 'footer-menu navbar-nav', // Add a custom class for styling
                  'container_class' => 'footer-nav-container',
                  'fallback_cb'    => false         // Disable the fallback to a page list
              ));
            ?>
            </div>
            <div class="col-md-6 border-left ps-4">
            <h3 class="h5 pb-3">Policy</h3>
              <?php
                wp_nav_menu(array(
                  'theme_location' => 'policy_menu',
                  'depth'             => 3,
                  'menu_class'     => 'footer-menu navbar-nav', // Add a custom class for styling
                  'container_class' => 'footer-nav-container',
                  'fallback_cb'    => false         // Disable the fallback to a page list
                ));
            ?>
            </div>
        </div>
        
    </div>
    <div class="col-md-3 border-left ps-4">
        <div class="contactformmain">
          <h3 class="h5 pb-3">Newsletter</h3>
          <p class="text-start">Subscribe to our Newsletter</p>
          <?php echo do_shortcode('[contact-form-7 id="10cc0f7" title="Newsletter"]') ?>
        </div>
    </div>
  </div>
  <hr class="mt-5"/>
  <div class="row pt-2">
    <div class="col-lg-12 site-sub-footer">
      <p>&copy; <?php echo date('Y'); ?> <a href="<?php //  echo home_url('/'); ?>"><? // bloginfo('name'); ?></a></p>
    </div>
  </div>
</footer>
</div>
  <?php wp_footer(); ?>
  <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.8/slick.min.js"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <script>
        $(document).ready(function(){
            $('.single-item').slick({
            slidesToShow: 1,
            dots:true,
            centerMode: false,
            });
    });
  </script>
</body>
</html>

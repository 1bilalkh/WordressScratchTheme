<!DOCTYPE html>
<html class="no-js">
<head>
	<title><?php wp_title('•', true, 'right'); bloginfo('name'); ?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.8/slick-theme.min.css" />
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body <?php body_class(); ?>>

<!--[if lt IE 8]>
<div class="alert alert-warning">
	You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.
</div>
<![endif]-->

<?php
$custom_logo_id = get_theme_mod( 'custom_logo' );
$logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );

?>


<div class="socialfull">
    <div class="container">
      <ul class="sociallinks">
        <li><i class='bx bxl-facebook'></i></li>
        <li><i class='bx bxl-twitter'></i></li>
        <li><i class='bx bxl-instagram'></i></li>
      </ul>
    </div>
</div>
<nav class="navbar navbar-expand-lg navbar-light bg-light pt-2 pb-2">
<div class="container">
    <div class="navbar-header">
      <a href="http://localhost/ecommerce-word/" class="logo">
          <?php 
              if ( has_custom_logo() ) {
                echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
              } else {
                echo '<h1>' . get_bloginfo('name') . '</h1>';
              }
          ?>
      </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      
    </div>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
     <!-- // <?php
           // wp_nav_menu( array(
             //   'theme_location'    => 'navbar-left',
               // 'depth'             => 2,
               // 'menu_class'        => 'nav navbar-nav d-none',
              //  'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
              //  'walker'            => new wp_bootstrap_navwalker())
          //  );
        ?> -->
        <div class="d-none">
          <?php get_template_part('includes/navbar-search'); ?>
          </div>
        <div class="d-none">
          <?php
              wp_nav_menu( array(
                  'theme_location'    => 'navbar-right',
                  'depth'             => 2,
                  'menu_class'        => 'nav navbar-nav navbar-right d-flex justify-content-end',
                  'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                  'walker'            => new Custom_Walker_Nav_Menu())
              );
          ?>
        </div>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'navbar-right',
            'menu_class' => 'nav navbar-nav navbar-right d-flex justify-content-end ms-auto',
            'container' => false, // No extra div or container
            'walker' => new Custom_Walker_Nav_Menu(), // Custom walker for dropdown functionality
        ));
    ?>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
  


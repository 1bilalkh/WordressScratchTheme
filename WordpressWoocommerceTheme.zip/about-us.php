<?php /* Template Name: About Us page */ ?>

<?php include ("includes/header.php"); ?>


				<div class="container">
      				<div class="row">
                      <h3 class="headingpg">About Us</h3>
                        <div class="col-md-12 mt-5 mb-5 p-0">
                            <img class="img-fluid w-100 rounded" src="<?php echo get_template_directory_uri(); ?>/images/Rectangle-90.jpg" alt="Description of Image">
                        </div>
                        <div class="col-md-4">
                            <h3 class="h1 text-center pt-3">We Are Unique</h3>
                        </div>
                        <div class="col-md-8">
                            <p class="h5 lh-base">After many years of enthusiastically creating fine jewelry as a team of friends, we ultimately decided to turn that hobby into an actual entrepreneurial project.</p>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-md-6">
                            <img class="img-fluid w-100 rounded" src="<?php echo get_template_directory_uri(); ?>/images/Rectangle-10.png" alt="Description of Image">
                        </div>
                        <div class="col-md-6">
                             <img class="img-fluid w-100 rounded" src="<?php echo get_template_directory_uri(); ?>/images/Rectangle-11.jpg" alt="Description of Image">
                        </div>
                    </div>
                    <div class="row mt-5 pt-4 deleivery">
                        <h3 class="h3 text-center pb-5">How do we Work</h3>
                        <div class="col-md-4 text-center border p-4 leftborder">
                            <div class="aboutdelivery  pt-3 pb-3">
                                <h5 class="h5">Fast Delivery</h5>
                                <p>You get your parcel quickly</p>
                            </div>
                        </div>
                        <div class="col-md-4 text-center  border p-4">
                            <div class="aboutdelivery pt-3 pb-3">
                                <h5 class="h5">Best Prices</h5>
                                <p>Make sure by yourself!</p>
                            </div>
                        </div>
                        <div class="col-md-4 text-center border p-4">
                            <div class="aboutdelivery  pt-3 pb-3">
                                <h5 class="h5">Large Assortment</h5>
                                <p>For all tastes</p>
                            </div>
                        </div>
                    </div>
				</div>
















<?php include ("includes/footer.php"); ?>
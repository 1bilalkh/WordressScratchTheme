<?php /* Template Name: Contact Us page */ ?>

<?php include ("includes/header.php"); ?>


				<div class="container">
                    <div class="row pt-2">

                        <h3 class="headingpg">Contact Us</h3>
                        <div style="height:26px;"></div>
                        <div class="col-md-6">
                            
                            <div class="contactboxes">
                            <div class="row">
                                <div class="col-md-6">
                                    <span class="contactbox">
                                        <p><span class="icon"><i class='bx bx-bulb'></i></span></p>
                                        <h4 class="heading">General Inquiries</h4>
                                        <p>Have an idea? Tell us about it!</p>  
                                        <p class="smallheading"><span>+1 (657) 298-1812</span></p>
                                        <p class="smallheading">hello@techigator.com</p> 
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="contactbox">
                                        <p><span class="icon"><i class='bx bx-bolt-circle'></i></span></p>
                                        <h4 class="heading">Media</h4>
                                        <p>Let’s have fun together!</p>  
                                        <p class="smallheading"><span>+1 (657) 298-1812</span></p>
                                        <p class="smallheading">hello@techigator.com</p> 
                                    </span>
                                </div>
                                <div class="col-md-6 pt-5">
                                    <span class="contactbox">
                                        <p><span class="icon"><i class='bx bx-bolt-circle'></i></span></p>
                                        <h4 class="heading">Headquarters</h4>
                                        <p>Something went wrong? Tell us! Tell our administration!</p>  
                                        <p class="smallheading"><span>+1 (657) 298-1812</span></p>
                                        <p class="smallheading">hello@techigator.com</p> 
                                    </span>
                                </div>
                                <div class="col-md-6 pt-5">
                                    <span class="contactbox">
                                        <p><span class="icon"><i class='bx bx-rocket' ></i></span></p>
                                        <h4 class="heading">Career</h4>
                                        <p>Brave visionaries and professionals are always welcome!</p>  
                                        <p class="smallheading">hr@ecommerce.com</p> 
                                    </span>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="contactform">
                                <h3>Don't hesitate!
                                    <br>
                                    Let's discuss your project</h3>
                                    <p>Send us a message with a brief description of your project. Our expert team will review it and get back to you within one business day with free consultation and to discuss the next steps.</p>
                                <?php
                                    echo do_shortcode('[contact-form-7 id="351a57b" title="Contact form 1"]');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>














<?php include ("includes/footer.php"); ?>
<?php /* Template Name: Home page */ ?>

<?php include ("includes/header.php"); ?>


				<div class="container">
      				<div class="single-item">
						<?php
							query_posts(array(
								'post_type' => 'my_slider', // Custom post type
								'posts_per_page' => -1,   // Fetch all posts
								'orderby' => 'menu_order', // Order by the custom field (if used for custom sorting)
								'order' => 'ASC',         // ASC (ascending) or DESC (descending)
							));
						?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<div><?php the_post_thumbnail('full'); ?></div>
							<?php endwhile; endif; ?>
							<?php wp_reset_query(); ?>
					</div>
				</div>
					<section class="mainpgproduct">
						<div class="container">
							<h1 class="d-block text-center h1 pt-5 pb-0">Trending Item</h1>
							<p class="d-block text-center pb-4">Take a look at Trending products</p>
							<div class="row pt-5">
								<?php echo do_shortcode('[products limit="4" columns]') ?>
							</div>
						</div>
					</section>
        <div class="container">
				<div class="row">

				<div class="col-md-7">
					<div class="col-md-12">
					<img class="img-fluid w-100" src="<?php echo get_template_directory_uri(); ?>/images/Sub-banner-01.jpg" alt="Description of Image">		
					</div>
				</div>
				<div class="col-md-5">
					<div class="col-md-12">
					<img class="img-fluid w-100"  src="<?php echo get_template_directory_uri(); ?>/images/Sub-banner-02.jpg" alt="Description of Image">		
					</div>
					<div class="col-md-12 pt-4">
					<img class="img-fluid w-100" src="<?php echo get_template_directory_uri(); ?>/images/Sub-banner-03.jpg" alt="Description of Image">		
					</div>
				</div>

				</div>
						</div>
				<section>
					
					
						<div class="parallexeffect text-white text-start">
							<div class="container">
							<h1 class="h1">Mountain Star Zlatibor</h1>
							<p class="pt-2 w-75 lh-base">Zlatibor is a mountain of exceptional beauty whose special geographical properties have made this mountain a real gem of western Serbia.</p>
							<a href="#" class="mt-3 text-white text-decoration-none">Learn more</a>
						</div>
					</div>
							
				</section>	
				<div class="container">
			<div class="pt-4 row">
				<?php
					query_posts(array(
						'post_type' => 'movies', // Custom post type
						'posts_per_page' => -1,   // Fetch all posts
						'orderby' => 'menu_order', // Order by the custom field (if used for custom sorting)
						'order' => 'ASC',         // ASC (ascending) or DESC (descending)
					));
					?>
					
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="col-md-6">
						
						<div class="services img-wrapper">
							<div class="servicesimg"><?php the_post_thumbnail('full'); ?> 
								<div class="imgtext">
									<p><?php the_title(); ?></p>
									<h5><?php the_title(); ?></h5>
									<a href="#">Shop Now</a>
								</div>
							</div>
						</div>
					</div>
						<?php endwhile; endif; ?>
						<?php wp_reset_query(); ?>
					</div>
				</div>
				</div>		
       		 </div>
				<section class="mainpgproduct">
					<div class="container">
						<h1 class="d-block text-center h1 pt-5 pb-0">Feature Products</h1>
						<p class="d-block text-center pb-4">Take a look at featured products</p>
						<div class="row pt-5">
							<?php echo do_shortcode('[products ids="243,241,239,237" ]') ?>
						</div>
					</div>
				</section>
				<div class="container">
					<div class="row">
					<h1 class="d-block text-center h1 pt-5 pb-5">FAQs</h1>
						<?php echo do_shortcode('[sp_easyaccordion id="245"]') ?>
					</div>
				</div>
				</div>
















<?php include ("includes/footer.php"); ?>